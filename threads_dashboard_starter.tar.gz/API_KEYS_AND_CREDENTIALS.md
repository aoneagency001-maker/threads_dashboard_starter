# 🔑 API Ключи и Учетные Данные - Полный Список

**⚠️ ВАЖНО: Этот файл содержит только ШАБЛОНЫ и ИНСТРУКЦИИ!**  
**НИКОГДА не коммитьте реальные ключи в Git!**

---

## 📋 Все необходимые API ключи и учетные данные

### 🤖 1. Google Gemini API (ОБЯЗАТЕЛЬНО - для извлечения цитат)

**Переменная:** `GEMINI_API_KEY`

**Где получить:**
1. Перейдите на https://aistudio.google.com/app/apikey
2. Войдите в Google аккаунт
3. Нажмите "Create API Key"
4. Скопируйте ключ (начинается с `AIza...`)

**Формат в .env:**
```env
GEMINI_API_KEY=AIzaSy...
```

**Статус:** ⭐ ОБЯЗАТЕЛЬНО - используется для глубокого сканирования книг

---

### 🧠 2. Anthropic Claude API (РЕКОМЕНДУЕТСЯ - для написания/редактирования)

**Переменная:** `ANTHROPIC_API_KEY`

**Где получить:**
1. Перейдите на https://console.anthropic.com/
2. Войдите или создайте аккаунт
3. Перейдите в раздел "API Keys"
4. Нажмите "Create Key"
5. Скопируйте ключ (начинается с `sk-ant-...`)

**Формат в .env:**
```env
ANTHROPIC_API_KEY=sk-ant-api03-...
```

**Статус:** ⭐ РЕКОМЕНДУЕТСЯ - основной выбор для полировки и редактирования текстов  
**Fallback:** Если недоступен, используется GPT-4o-mini

---

### 🤖 3. OpenAI API (ОПЦИОНАЛЬНО - fallback, если Claude недоступен)

**Переменная:** `OPENAI_API_KEY`

**Где получить:**
1. Перейдите на https://platform.openai.com/api-keys
2. Войдите в аккаунт OpenAI
3. Нажмите "Create new secret key"
4. Скопируйте ключ (начинается с `sk-...`)

**Формат в .env:**
```env
OPENAI_API_KEY=sk-...
```

**Статус:** ⚠️ ОПЦИОНАЛЬНО - используется только как fallback, если Claude недоступен  
**Можно пропустить:** Если используете только Gemini + Claude

---

### 📱 4. Threads API - Официальный метод (Instagram Graph API)

**Переменные:**
- `THREADS_ACCESS_TOKEN` - токен доступа
- `IG_USER_ID` или `THREADS_USER_ID` - ID Instagram пользователя

**Где получить:**

#### Шаг 1: Создайте Facebook App
1. Перейдите на https://developers.facebook.com/apps
2. Нажмите "Create App"
3. Выберите тип "Business" или "Other"
4. Заполните название и email

#### Шаг 2: Добавьте Instagram Graph API
1. В панели приложения найдите "Add Products"
2. Найдите "Instagram Graph API"
3. Нажмите "Set Up"

#### Шаг 3: Получите Access Token
1. Откройте https://developers.facebook.com/tools/explorer/
2. Выберите ваше приложение
3. Нажмите "Generate Token"
4. Выберите разрешения:
   - `instagram_basic`
   - `instagram_content_publish`
   - `pages_read_engagement`
5. Скопируйте токен

#### Шаг 4: Получите Instagram User ID
1. В Graph API Explorer используйте ваш токен
2. Выполните запрос: `GET /me/accounts`
3. Найдите вашу страницу
4. Выполните: `GET /{page-id}?fields=instagram_business_account`
5. Скопируйте `instagram_business_account.id`

**Формат в .env:**
```env
THREADS_ACCESS_TOKEN=EAAx...
IG_USER_ID=12345678901234567
THREADS_USER_ID=12345678901234567
```

**Статус:** ⚠️ ОПЦИОНАЛЬНО - нужно только для публикации постов  
**Примечание:** Требуется Business/Creator аккаунт Instagram

---

### 📱 5. Threads API - Неофициальный метод (логин/пароль)

**Переменные:**
- `INSTAGRAM_USERNAME` - ваш username Instagram
- `INSTAGRAM_PASSWORD` - ваш пароль Instagram

**Формат в .env:**
```env
INSTAGRAM_USERNAME=your_username
INSTAGRAM_PASSWORD=your_password
```

**Статус:** ⚠️ ОПЦИОНАЛЬНО - альтернативный метод публикации  
**⚠️ БЕЗОПАСНОСТЬ:** Пароль хранится в открытом виде в .env - используйте с осторожностью  
**Рекомендуется:** Использовать официальный метод через токены

---

## 📝 Полный шаблон .env файла

```env
# ============================================
# AI МОДЕЛИ ДЛЯ ОБРАБОТКИ ТЕКСТОВ
# ============================================

# Google Gemini API (ОБЯЗАТЕЛЬНО)
# Получить: https://aistudio.google.com/app/apikey
GEMINI_API_KEY=AIzaSy...

# Anthropic Claude API (РЕКОМЕНДУЕТСЯ)
# Получить: https://console.anthropic.com/
ANTHROPIC_API_KEY=sk-ant-api03-...

# OpenAI API (ОПЦИОНАЛЬНО - fallback)
# Получить: https://platform.openai.com/api-keys
OPENAI_API_KEY=sk-...

# ============================================
# THREADS API - ОФИЦИАЛЬНЫЙ МЕТОД
# ============================================

# Access Token (получить через Graph API Explorer)
# Инструкция: QUICK_GRAPH_API_SETUP.md
THREADS_ACCESS_TOKEN=EAAx...

# Instagram User ID (получить через Graph API Explorer)
IG_USER_ID=12345678901234567
THREADS_USER_ID=12345678901234567

# ============================================
# THREADS API - НЕОФИЦИАЛЬНЫЙ МЕТОД
# ============================================

# Логин и пароль Instagram (альтернатива официальному методу)
# ⚠️ ВНИМАНИЕ: Пароль хранится в открытом виде!
INSTAGRAM_USERNAME=your_instagram_username
INSTAGRAM_PASSWORD=your_instagram_password
```

---

## 🔐 Приоритет настройки

### Минимальная конфигурация (только извлечение цитат):

```env
GEMINI_API_KEY=...  # ОБЯЗАТЕЛЬНО
```

### Рекомендуемая конфигурация (полный функционал):

```env
GEMINI_API_KEY=...          # ОБЯЗАТЕЛЬНО
ANTHROPIC_API_KEY=...       # РЕКОМЕНДУЕТСЯ
THREADS_ACCESS_TOKEN=...    # Для публикации
IG_USER_ID=...             # Для публикации
```

### Полная конфигурация (с fallback):

```env
GEMINI_API_KEY=...          # ОБЯЗАТЕЛЬНО
ANTHROPIC_API_KEY=...       # РЕКОМЕНДУЕТСЯ
OPENAI_API_KEY=...          # Fallback
THREADS_ACCESS_TOKEN=...    # Для публикации
IG_USER_ID=...             # Для публикации
```

---

## 🛡️ Безопасность

### ⚠️ КРИТИЧЕСКИ ВАЖНО:

1. **НЕ КОММИТЬТЕ `.env` файл в Git!**
   - Убедитесь что `.env` в `.gitignore`
   - Никогда не публикуйте токены в репозитории

2. **Храните секреты безопасно:**
   - Используйте переменные окружения
   - Для продакшена используйте секретные хранилища (AWS Secrets Manager, HashiCorp Vault)

3. **Минимальные разрешения:**
   - Для публикации нужен только `instagram_content_publish`
   - Не запрашивайте лишние разрешения

4. **Регулярно обновляйте токены:**
   - Краткосрочные токены живут 1-2 часа
   - Долгосрочные токены ~60 дней

---

## 📋 Чеклист настройки

### Базовый функционал:
- [ ] Получен `GEMINI_API_KEY`
- [ ] Добавлен в `.env`
- [ ] Установлены зависимости: `pip install -r requirements.txt`

### Полный функционал:
- [ ] Получен `ANTHROPIC_API_KEY`
- [ ] Добавлен в `.env`
- [ ] Получен `THREADS_ACCESS_TOKEN`
- [ ] Получен `IG_USER_ID`
- [ ] Добавлены в `.env`

### Fallback (опционально):
- [ ] Получен `OPENAI_API_KEY`
- [ ] Добавлен в `.env`

---

## 🔗 Быстрые ссылки

### Получение API ключей:

- **Gemini:** https://aistudio.google.com/app/apikey
- **Claude:** https://console.anthropic.com/
- **OpenAI:** https://platform.openai.com/api-keys
- **Threads (Meta):** https://developers.facebook.com/

### Документация:

- **Graph API Explorer:** https://developers.facebook.com/tools/explorer/
- **Instagram API Docs:** https://developers.facebook.com/docs/instagram-api/
- **Threads API Docs:** https://developers.facebook.com/docs/threads/

---

## 💡 Советы

1. **Начните с Gemini** - это самый важный ключ для извлечения цитат
2. **Добавьте Claude** - для лучшего качества редактирования
3. **Threads API настройте позже** - если планируете публикацию
4. **OpenAI можно пропустить** - если используете Claude

---

## 📞 Поддержка

Если возникли проблемы с получением ключей:

1. Проверьте документацию поставщика API
2. Убедитесь что аккаунт активен
3. Проверьте лимиты использования
4. Проверьте `.env` файл (нет лишних пробелов, правильный формат)

---

**⚠️ ПОМНИТЕ:** Никогда не публикуйте реальные ключи!  
**✅ Используйте:** Шаблоны и инструкции выше для получения своих ключей.

