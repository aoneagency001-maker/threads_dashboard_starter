# Threads Dashboard (Cursor Starter)

## Quickstart
1) In Cursor, open this folder as a project.
2) In terminal: `pip install -r requirements.txt`
3) Run: `streamlit run app.py`
4) Browser UI: 4 tabs (Content / AI Gen / Publish / Parsing).
