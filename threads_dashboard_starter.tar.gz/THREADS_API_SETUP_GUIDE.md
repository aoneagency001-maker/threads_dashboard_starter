# 📚 Полная инструкция по настройке Threads API

Это руководство поможет вам настроить работу с Threads API для публикации постов и взаимодействия с платформой.

## 🎯 Способы работы с Threads API

В проекте доступно **два способа** работы с Threads API:

### Способ 1: Instagram Graph API (официальный, рекомендуемый)
- ✅ Официальный API от Meta
- ✅ Более стабильный и надежный
- ✅ Требует создание Facebook App и настройку OAuth
- ⚠️ Требует больше времени на настройку

### Способ 2: threads-api библиотека (неофициальный)
- ✅ Быстрая настройка (только логин/пароль)
- ✅ Больше возможностей (лайки, подписки, ответы и т.д.)
- ⚠️ Неофициальный метод, может быть менее стабильным
- ⚠️ Требует передачу логина/пароля от Instagram

---

## 🚀 Способ 1: Настройка через Instagram Graph API

### Шаг 1: Создание Facebook App

1. Перейдите на [Facebook Developers](https://developers.facebook.com/)
2. Войдите в свой аккаунт Facebook
3. Нажмите **"Мои приложения"** (My Apps) → **"Создать приложение"** (Create App)
4. Выберите тип приложения: **"Бизнес"** или **"Другое"**
5. Заполните информацию:
   - **Название приложения**: любое (например, "Threads Dashboard")
   - **Email**: ваш email
   - **Назначение приложения**: выберите подходящее

### Шаг 2: Добавление продукта Instagram Graph API

1. В панели управления приложением найдите раздел **"Добавить продукты"**
2. Найдите **"Instagram Graph API"** и нажмите **"Настроить"**
3. В боковом меню выберите **"Основные настройки"** (Basic Settings)

### Шаг 3: Получение Access Token

#### Вариант А: Использование Graph API Explorer (для тестирования)

1. Перейдите в [Graph API Explorer](https://developers.facebook.com/tools/explorer/)
2. Выберите ваше приложение из выпадающего списка
3. Нажмите **"Создать токен"** (Generate Token)
4. Выберите разрешения:
   - `instagram_basic`
   - `instagram_content_publish`
   - `pages_show_list`
   - `pages_read_engagement`
5. Нажмите **"Создать токен доступа"**
6. **⚠️ ВАЖНО**: Скопируйте токен - он понадобится для `.env` файла

#### Вариант Б: Долгосрочный токен (Long-lived token)

1. Используя Graph API Explorer, получите краткосрочный токен (как в Варианте А)
2. Откройте в браузере (замените `SHORT_LIVED_TOKEN` на ваш токен):
   ```
   https://graph.facebook.com/v18.0/oauth/access_token?grant_type=fb_exchange_token&client_id=YOUR_APP_ID&client_secret=YOUR_APP_SECRET&fb_exchange_token=SHORT_LIVED_TOKEN
   ```
3. Получите долгосрочный токен из ответа

### Шаг 4: Получение Instagram User ID

1. В [Graph API Explorer](https://developers.facebook.com/tools/explorer/) используйте ваш токен
2. Выполните запрос: `GET /me/accounts`
3. Найдите ваш Instagram Business аккаунт и скопируйте `instagram_business_account.id`
4. Это и есть ваш `IG_USER_ID`

**Альтернативный способ:**
- Используйте онлайн инструменты для конвертации username в User ID
- Или используйте API: `GET /me?fields=instagram_business_account`

### Шаг 5: Настройка .env файла

1. Скопируйте `env_template.txt` в `.env`:
   ```bash
   cp env_template.txt .env
   ```

2. Откройте `.env` и заполните:
   ```env
   THREADS_ACCESS_TOKEN=ваш_токен_из_шага_3
   IG_USER_ID=ваш_user_id_из_шага_4
   ```

### Шаг 6: Проверка настройки

Запустите ваше приложение:
```bash
streamlit run app.py
```

Нажмите кнопку **"🚀 Опубликовать в Threads"** и проверьте, что пост публикуется успешно.

---

## 🔧 Способ 2: Настройка через threads-api библиотеку

### Шаг 1: Установка зависимостей

Библиотека `threads-api` уже включена в проект. Если нужно установить отдельно:

```bash
pip install threads-api
```

Также убедитесь, что установлены все зависимости:
```bash
pip install -r requirements.txt
```

Дополнительные зависимости для threads-api:
```bash
pip install aiohttp cryptography colorama
```

### Шаг 2: Настройка .env файла

1. Откройте `.env` файл (или создайте его из шаблона)
2. Добавьте ваши учетные данные Instagram:

```env
# Для threads-api библиотеки
INSTAGRAM_USERNAME=ваш_instagram_username
INSTAGRAM_PASSWORD=ваш_instagram_пароль

# Логирование (опционально)
LOG_LEVEL=INFO
```

⚠️ **ВАЖНО**: 
- Используйте тот же Instagram аккаунт, который привязан к Threads
- Если включена двухфакторная аутентификация, возможно потребуется дополнительная настройка
- Не коммитьте `.env` файл в git (должен быть в `.gitignore`)

### Шаг 3: Проверка настройки

Создайте тестовый файл `test_threads_api.py`:

```python
from threads_api.src.threads_api import ThreadsAPI
import asyncio
import os
from dotenv import load_dotenv

load_dotenv()

async def test_login():
    api = ThreadsAPI()
    
    username = os.getenv('INSTAGRAM_USERNAME')
    password = os.getenv('INSTAGRAM_PASSWORD')
    
    if not username or not password:
        print("❌ Не найдены INSTAGRAM_USERNAME или INSTAGRAM_PASSWORD в .env")
        return
    
    # Логин с сохранением токена в .token файл
    is_success = await api.login(
        username=username, 
        password=password, 
        cached_token_path=".token"
    )
    
    if is_success:
        print("✅ Успешный вход в Threads API!")
        
        # Тест: получение информации о пользователе
        user_id = await api.get_user_id_from_username(username)
        print(f"📱 Ваш User ID: {user_id}")
        
        # Тест: получение профиля
        profile = await api.get_user_profile(user_id)
        print(f"👤 Профиль: @{profile.username}")
        print(f"📝 Bio: {profile.biography}")
    else:
        print("❌ Ошибка входа")
    
    await api.close_gracefully()

if __name__ == "__main__":
    asyncio.run(test_login())
```

Запустите тест:
```bash
python test_threads_api.py
```

### Шаг 4: Использование в вашем приложении

Пример интеграции в `app.py`:

```python
import asyncio
from threads_api.src.threads_api import ThreadsAPI
import os
from dotenv import load_dotenv

load_dotenv()

async def publish_to_threads_async(caption: str) -> bool:
    """Публикует пост через threads-api библиотеку"""
    api = ThreadsAPI()
    
    username = os.getenv("INSTAGRAM_USERNAME")
    password = os.getenv("INSTAGRAM_PASSWORD")
    
    if not username or not password:
        return False
    
    try:
        await api.login(username=username, password=password, cached_token_path=".token")
        result = await api.post(caption=caption)
        
        if result and result.media.pk:
            await api.close_gracefully()
            return True
    except Exception as e:
        print(f"Ошибка: {e}")
        await api.close_gracefully()
        return False
    
    return False

def publish_to_threads(caption: str) -> bool:
    """Синхронная обертка для публикации"""
    return asyncio.run(publish_to_threads_async(caption))
```

---

## 📝 Доступные возможности через threads-api

### Публикация постов
```python
# Текстовый пост
result = await api.post("Привет, Threads!")

# Пост с изображением
result = await api.post("Смотрите картинку!", image_path="path/to/image.jpg")

# Пост с несколькими изображениями
result = await api.post("Несколько фото!", image_path=["img1.jpg", "img2.jpg"])

# Ответ на пост
result = await api.post("Мой ответ", parent_post_id="post_id")

# Репост с комментарием (quote)
result = await api.post("Мое мнение", quoted_post_id="post_id")
```

### Взаимодействие с постами
```python
# Лайк
await api.like_post(post_id)

# Убрать лайк
await api.unlike_post(post_id)

# Репост
await api.repost(post_id)

# Удалить репост
await api.delete_repost(post_id)

# Удалить свой пост
await api.delete_post(post_id)
```

### Работа с пользователями
```python
# Получить User ID по username
user_id = await api.get_user_id_from_username("zuck")

# Получить профиль
profile = await api.get_user_profile(user_id)

# Получить посты пользователя
threads = await api.get_user_threads(user_id)

# Подписаться на пользователя
await api.follow_user(user_id)

# Отписаться
await api.unfollow_user(user_id)

# Получить подписчиков
followers = await api.get_user_followers(user_id)

# Получить подписки
following = await api.get_user_following(user_id)
```

### Чтение ленты
```python
# Получить timeline
timeline = await api.get_timeline()

# Получить уведомления
notifications = await api.get_notifications()
```

---

## ⚠️ Важные замечания и решения проблем

### Проблема: "Login failed" или ошибки авторизации

**Решения:**
1. Проверьте правильность username и password в `.env`
2. Убедитесь, что Instagram аккаунт не заблокирован
3. Если включена 2FA, возможно потребуется временно отключить для API доступа
4. Попробуйте удалить файл `.token` и войти заново

### Проблема: "User not onboarded to threads.net"

**Решение:**
- Убедитесь, что ваш Instagram аккаунт связан с Threads
- Войдите в Threads через официальное приложение хотя бы один раз

### Проблема: Rate limiting (лимиты запросов)

**Решения:**
- Используйте `cached_token_path` для переиспользования токена
- Делайте паузы между запросами
- Не публикуйте слишком часто (рекомендуется не чаще 1 поста в минуту)

### Проблема: Токен Instagram Graph API истек

**Решения:**
1. Используйте долгосрочный токен (Long-lived token)
2. Настройте автоматическое обновление токена
3. Для продакшена используйте OAuth flow с refresh token

### Проблема: Не работает публикация через Graph API

**Проверьте:**
1. Правильность `THREADS_ACCESS_TOKEN` в `.env`
2. Правильность `IG_USER_ID` в `.env`
3. Что у токена есть разрешение `instagram_content_publish`
4. Что Instagram Business аккаунт правильно связан с Facebook страницей

---

## 🔐 Безопасность

### ⚠️ КРИТИЧЕСКИ ВАЖНО:

1. **НЕ КОММИТЬТЕ `.env` файл в git!**
   - Убедитесь, что `.env` в `.gitignore`
   - Никогда не публикуйте токены в репозитории

2. **Храните секреты безопасно:**
   - Используйте переменные окружения
   - Для продакшена используйте секретные хранилища (AWS Secrets Manager, HashiCorp Vault и т.д.)

3. **Используйте минимально необходимые разрешения:**
   - Для публикации нужен только `instagram_content_publish`
   - Не запрашивайте лишние разрешения

4. **Регулярно обновляйте токены:**
   - Краткосрочные токены истекают через 1-2 часа
   - Долгосрочные токены действуют ~60 дней

---

## 📚 Дополнительные ресурсы

- [Instagram Graph API Документация](https://developers.facebook.com/docs/instagram-api/)
- [Threads API на GitHub](https://github.com/Danie1/threads-api)
- [Facebook Developers Portal](https://developers.facebook.com/)
- [Graph API Explorer](https://developers.facebook.com/tools/explorer/)

---

## ✅ Чеклист настройки

- [ ] Создан Facebook App
- [ ] Добавлен продукт Instagram Graph API
- [ ] Получен Access Token
- [ ] Получен Instagram User ID
- [ ] Создан `.env` файл с правильными значениями
- [ ] Проверена публикация через Graph API
- [ ] (Опционально) Настроен threads-api с логином
- [ ] Проверена работа всех функций
- [ ] `.env` добавлен в `.gitignore`

---

## 🎉 Готово!

Теперь вы можете работать с Threads API. Если возникнут проблемы, проверьте раздел "Решения проблем" выше или создайте issue в репозитории.

**Удачи в работе с Threads! 🚀**

