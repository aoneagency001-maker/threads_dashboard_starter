# Backend package for quotes extraction

